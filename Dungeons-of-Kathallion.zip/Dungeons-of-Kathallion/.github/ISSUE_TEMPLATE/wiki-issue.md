---
name: Wiki Issue
about: For missing or incorrect information (or just typos) in the wiki.
title: ''
labels: documentation
assignees: ''

---

**Where is the issue**
i.e, "[this](where the error is wiki page) wiki page"

**What the issue is**
i.e, "Typo: helath instead of health"

**Expected content**
i.e, "I expected there to not be a typo"
