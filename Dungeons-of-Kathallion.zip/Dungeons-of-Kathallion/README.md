# Dungeons-of-Kathallion
A text adventure game about exploring the Dungeons of Kathallion. You can battle monsters, pick up weapons, and discover hidden secrets.

## To Play
See [this](https://github.com/lumbar527/Dungeons-of-Kathallion/wiki/Running_the_game) page.

## Progress
Beta is out! A mostly complete engine now exists!